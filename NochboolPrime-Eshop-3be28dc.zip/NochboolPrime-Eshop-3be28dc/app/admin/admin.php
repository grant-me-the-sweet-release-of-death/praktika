<h1>Администрирование магазина</h1>
<h3>Доступные действия:</h3>
<ul>
    <li><a href='catalog'>Каталог товаров</a></li>
    <li><a href='admin/add_item_to_catalog'>Добавление товара в каталог</a></li>
    <li><a href='admin/orders'>Просмотр готовых заказов</a></li>
    <li><a href='admin/create_user'>Добавить пользователя</a></li>
    <li><a href='admin/logout'>Завершить сеанс</a></li>
</ul>