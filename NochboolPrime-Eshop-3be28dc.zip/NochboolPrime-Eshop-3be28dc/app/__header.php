<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Книжный магазин</title>
	<link rel='stylesheet' href='/css/style.css'>
</head>
<body>