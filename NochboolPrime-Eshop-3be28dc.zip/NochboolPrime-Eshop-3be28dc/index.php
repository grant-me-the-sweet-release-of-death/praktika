<?php
error_reporting(E_ALL);

require_once 'core/init.php';

require_once 'app/__header.php';
require_once 'app/__router.php';
require_once 'app/__footer.php';
